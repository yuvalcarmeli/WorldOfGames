import requests
from currency_converter import CurrencyConverter
def get_money_interval(difficulty):
    url = 'https://v6.exchangerate-api.com/v6/a384ee03308df33256c0d601/latest/USD'
    response = requests.get(url)
    response.raise_for_status()
    data = response.json()
    rate = data['conversion_rates']['ILS']
    lower_bound = rate - 5 - difficulty
    upper_bound = rate + 5 - difficulty
    return lower_bound , upper_bound

def get_guess_from_user():
    while True:
        try:
            guess_user = int(input(f"what is the value of the generated number from USD to ILS:"))
            return guess_user
        except BaseException as e:
            print(f"you didnt enter an integer")


def play(difficulty):
    user_guess = get_guess_from_user()
    Lowest_range,Highest_range = get_money_interval(difficulty)
    if Lowest_range <= user_guess <= Highest_range:
        print("True")
    else:
        print("False")


